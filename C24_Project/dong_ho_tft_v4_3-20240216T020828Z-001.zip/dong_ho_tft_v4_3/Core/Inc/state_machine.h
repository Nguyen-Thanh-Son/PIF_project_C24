#ifndef _STATE_MACHINE_H_
#define _STATE_MACHINE_H_
#include "stdint.h"

//extern char buffer[30];
//extern char status[10];

void mode_default(void);
void machine_case_0(void);
void machine_case_1(void);
void machine_case_2(void);
void machine_case_3(void);
void machine_case_4(void);
void machine_case_5(void);
void machine_case_6(void);
//int button_handle(void)
#endif
